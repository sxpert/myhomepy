﻿namespace OpenWebNet
{
    #region Using

    using System;
    using OpenWebNet.Common;

    #endregion

    public class Device
    {
        public Where Where { get; set; }
    }
}
