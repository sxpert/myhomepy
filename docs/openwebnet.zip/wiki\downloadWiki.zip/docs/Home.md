**Project Description**
.Net libraries for OpenWebNet protocol and some tools

OpenWebNet is the protocol used to communicate with MyHome electric network created by Bticino.
You can find more info at www.myopen-bticino.it

Here you can find the .Net libs, in order to communicate with MyHome devices, and some tools which use them.
Libs support USB/Serial RS232 Gateway and Ethernet Gateways (therefore you can't manage all types of devices from the former)

There are still a lot of things to do and we release them as soon as possible.

For help or questions send me a message.

Thanks to Lorenzo and Mirko for their support.